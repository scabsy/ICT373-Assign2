package assignment2;

/**
 * @author Samuel Brownley 31691379
 * @version 1.0
 * @date 22/05/2017
 * @filename Assignment2.java
 */
public class Assignment2
{
    public static void main(String[] args) 
    {
        GUI familyTree = new GUI();
    }    
}
